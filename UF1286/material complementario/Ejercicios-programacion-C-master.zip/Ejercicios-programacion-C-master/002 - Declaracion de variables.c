// DECLARACI�N DE VARIABLES

// Librerias
#include <stdio.h>
#include <stdlib.h>

// Funcion principal
int main(void) {
	// Variables
	char letra;
	int entero;
	float flotante;
	// CHAR es una variable de tipo caracter, puede almacenar �nicamente un caracter, por ejemplo 'd'
	// INT almacena n�meros enteros
	// FLOAT almacena n�meros decimales
	
	// Variables conjuntas
	char letra2, caracter;
	int entero2, numero;
	float flotante2, decimal;
	// Se pueden declarar varias variables en una misma l�nea
	getchar();
	
	return 0;
}
