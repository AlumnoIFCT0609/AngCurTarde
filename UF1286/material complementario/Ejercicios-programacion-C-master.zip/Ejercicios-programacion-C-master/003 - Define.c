// DEFINE

// Librerias
#include <stdio.h>
#include <stdlib.h>

// Define
#define NUMERO 8
// Le da el valor 8 a NUMERO

// Funcion principal
int main(void) {
	// Sacando el valor NUMERO
	printf("El valor de NUMERO es: %d\n", NUMERO);
	
	getchar();
	
	return 0;
}
