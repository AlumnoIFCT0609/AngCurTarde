// PRINTF

#include <stdio.h>

// FUNCI�N PRINCIPAL
int main() {
	printf("Hola mundo!\n");
	
	// HACEMOS PAUSA
	fflush(stdin);
	printf("Presiona una tecla para terminar.\n");
	getch();
	return 0;
}
