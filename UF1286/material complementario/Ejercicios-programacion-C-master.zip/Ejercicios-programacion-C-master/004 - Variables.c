// VARIABLES

// Librerias
#include <stdio.h>
#include <stdlib.h>

// Funcion principal
int main(void) {
	// Dando valores a variables
	float x,y;
	x = 38.35646;
	y = -0.6540;
	
	// Imprimiendo en pantalla valores
	printf("Las coordeadas X e Y son: %f, %f.\n",x,y);
	
	getchar();
	
	return 0;
}
