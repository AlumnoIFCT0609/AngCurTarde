// Primer programa

// Librerias
#include <stdio.h>
#include <stdlib.h>

// Funcion principal
int main(void) {
	
	// Mensaje en pantalla
	printf("Mi primer programa.\n");
	
	// Hacemos una pausa
	printf("Presiona Intro para finalizar...");
	getchar();
	
	return 0;
}
