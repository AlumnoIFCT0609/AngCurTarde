// CADENA CON FORMATO

#include <stdio.h>

// FUNCI�N PRINCIPAL
int main() {
	int x = 8;
	
	printf("X = %d.\n",x);
		
	printf("Presiona una tecla para terminar...");
	fflush(stdin);
	getch();
	return 0;
}
