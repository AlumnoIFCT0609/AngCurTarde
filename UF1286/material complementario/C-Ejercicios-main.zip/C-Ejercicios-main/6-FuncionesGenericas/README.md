# Funciones genericas

Las funciones genericas en C son capaces gracias a los punteros void (*void).

Estos punteros son genericos ya que no tienen un tipo de dato asignado y ya que son punteros(direcciones de memoria), ocupan la misma cantidad de memoria que cualquier otro 
puntero de cualquier tipo, ya sea "int", "char", "float", etc...

Tambien para empesar por este tema es necesario saber y conocer la sintaxis de punteros a funciones y como utilizarlos.
