#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{
    int num = 149;
    int m = 4;
//    double num = 2;
//    double m = 6;

//    printf("\nFactorial de %d: %u", num, factorial(num));
//    printf("\nCombinatoria de %d / %d: %u", m, num, combinatoriaMsobreN(m, num));
//    printf("\n%.2lf ^ %.2lf: %.2lf", num, m, pow_MIO(num, m));
//    printf("\nFibonacci de %d --> %d", num, perteneceAFibonacci(num));
//    mostrarClasificacion(12);

//    printf("Multiplicador por sumas: %d", productosPorSuma(7, 9));
//    printf("Division por resta: %d", cocienteEntero(18, 122));
    num = 991;
//    printf("Suma de los %ds numeros naturales: %d", num, sumaNumerosNaturales(num));
//    printf("Suma de los %ds numeros naturales: %d", num, sumaNumerosNaturalesPares(num));

//    printf("Es %d un numero primo ?: %s", num, esNumeroPrimo(num)? "Si" : "No");
//    printf("\nAbsoluto: %d", absoluto(-36));

//    printf("\n\nMultiplicacion Rusa: %d", multiplicacionRusa(9, 9));
//    printf("\n\nParte Entera: %d", parteEntera(8.9999));

    printf("\n\n");
    return 0;

}
