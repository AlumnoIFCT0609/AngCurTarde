# Enunciados

Emular con una funcion propia el comportamiento de las funciones de la libreria "<string.h>". Buscar informacion en la documentacion sobre como se comporta no solo en los 
casos comunes, si no en los casos limites tambien. Ej: ¿Qué sucede si le paso una cadena vacia?

1. strlen()
2. strcat()
3. strchr()
4. strcmp()
5. strncmp()
6. strcpy()
7. strncpy()
8. strncat()
9. strrchr()
10. strstr()

Funciones personalizadas agregadas

11. str_lwr(String cad): Pasa toda una cadena a minuscula.
12. str_upp(String cad): Pasa toda una cadena a mayuscula.

Nota: Utilizar artimetica de punteros, no indireccion(cad[i], *(cad + i) => MAL)
