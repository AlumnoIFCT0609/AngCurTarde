# Archivos Binarios

- Copia directamente una porcion de memoria. No analiza nada. Toma un bloque de memoria y asi como lo toma en bytes, lo pega en el archivo.
- Ventaja: Es rapido por lo mencionado anteriormente. Copia y pega lso bloques de memoria(bytes) tal cual como viene sin interpretar nada.
- Desventaja: Es dependiente de la arquitectura con la cual trabajo. Si trabajo en 64bits y otro en 16bits y se comparte el archivo binario, habra problemas de lectura.
        
        
Para todos los ejercicios (porque hay otras formas): Todos los registros tendran exactamente la misma estructura, lo que se traduce a que tendran la misma cantidad de bytes 
independientemente de los datos de cada uno de los registros. 

